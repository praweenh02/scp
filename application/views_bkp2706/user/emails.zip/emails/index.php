 <div class="page-heading">
    <div class="row">
                    <div class="col-md-7">
                    <h3>
                      
                   Email Subscription
                       
                   </h3>
               </div>
              
        </div>    
        <hr>
</div>
<form id="email-subs" method="post" name="email-subs">
                   <?php  $csrf = array(
                             'name' => $this->security->get_csrf_token_name(),
                             'hash' => $this->security->get_csrf_hash());
                             ?>

                             <input type="hidden" id="csrf_token_name" name="<?=$csrf['name'];?>" value="<?=$csrf['hash'];?>" /> 
<div class="wrapper">
        <div class="row">
        <div class="col-sm-12">
        <section class="panel">
        <header class="panel-heading">
           Group List
               <span class="mb-5 pull-right" >
                        <button onclick="save_data();" type="button"  class="btn btn-success btn-sm btn-submit">
                            Submit
                        </button>
                   </span>
         
        </header>
        <div class="panel-body">
        <div class="adv-table">
        <table  class="display table table-bordered table-striped" id="dynamic-table">
        <thead>
        <tr>
            <th class="numeric">Sr.No.</th>
            <th>SDO Name</th>
            <th class="numeric">Working Group</th> 
            <th class="numeric">Action</th>
         </tr>
        </thead>
        <tbody id="loadallData">
            <?php
            error_reporting(0);
            $i=1;
            $user_id = $this->session->userdata('user_id');
            
                

                foreach ($group_list as  $value) 
                {
                $result = $this->db->select('*')->where('group_id',$value->group_id)->where('user_id',$user_id)->get('email_subscription')->row();
                    ?>
                    
                <tr>
                    <td><?=$i;?></td>
                    <td><?=$value->category_name;?></td>
                    <td><?=$value->group_name;?></td>
                    <td>
                        <input type="hidden" name="group_id[]" id="group_id" value="<?=$value->group_id;?>">
                        <input type="checkbox"  <?=($result->email_subscription=='Y') ? 'checked':'' ?>  class="form-control get_value"  id="email_subscription" name="email_subscription[]"  value="Y" style="width: 150%;">
                    </td>
                </tr>
                 
           <?php  $i++;}
            ?>
          
          
      
       
       
         </tbody>
        </table>
        </div>
        </div>
      </section>
        </div>
        </div>
      </div>
      

      <div id="popupdiv"></div>
</form>
<script src="ajax/email-subscription.js"></script>


                          



    
