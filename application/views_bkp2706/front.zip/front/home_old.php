  <div class="service-slider">
         
               <div id="myCarousel" class="carousel slide" data-ride="carousel">


          
               <!-- The slideshow -->
               <div class="carousel-inner">
                     <div class="assets/front/item carousel-item active">
                       <img src="assets/front/images/banner3.jpg" alt="Uttar Pradesh National Health Mission" width="100%">
                     </div>
                <div class="item carousel-item">
                    <img src="assets/front/images/banner1.jpeg" alt="Uttar Pradesh National Health Mission" width="100%">
                </div>
                <div class="item carousel-item">
                    <img src="assets/front/images/banner2.jpeg" alt="Uttar Pradesh National Health Mission" width="100%">
                </div>
              
                </div>

               <!-- Left and right controls -->
               <a class="carousel-control-prev" href="#myCarousel" data-slide="prev">
                <span class="carousel-control-prev-icon"></span>
               </a>
               <a class="carousel-control-next" href="#myCarousel" data-slide="next">
                <span class="carousel-control-next-icon"></span>
              </a>
            </div>
             </div>

    </div>



    <!--Top Content-->

    <!--<div class="top_content">
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-12 pd-40 bg1">
                    <div class="chairperson">
                        <h2><i class="fa fa-angle-right ic" aria-hidden="true"></i> Sri Jai Pratap Singh</h2>
                        <p>Minister of Medical Health & Family Welfare, Government of U.P.</p>
                    </div>
                </div>
                <br />
                <div class="col-md-4 col-12 pd-40 bg2">
                    <div class="chairperson">
                        <h2><i class="fa fa-angle-right ic" aria-hidden="true"></i> Dr. Devesh Chaturvedi, I.A.S.</h2>
                        <p>Principal Secretary Medical Health & Family Welfare, U.P.</p>
                    </div>
                </div>

                <div class="col-md-4 col-12 pd-40 bg1">
                    <div class="chairperson">
                        <h2> <i class="fa fa-angle-right ic" aria-hidden="true"></i> Sri Vijay Vishwas Pant, I.A.S.</h2>
                        <p>Mission Director National Health Mission, U.P.</p>
                    </div>
                </div>

            </div>
        </div>
    </div>-->


    <!--Event & Important Links-->

    <div class="events mt-80 mb-5">
        <div class="container">
            <div class="row">

                <div class="col-md-6">
                    <div class="event_container">
                        <h2><i class="fa fa-angle-right ic" aria-hidden="true"></i> Latest Groups<br /></h2>
                        <div id="myCarousel2" class="carousel slide" data-ride="carousel">
                            <div class="carousel-inner">
                                <div class="item carousel-item active">
                                    <div class="box">
                                        <div class="row">
                                            <div class="col-md-2 col-2"><img src="assets/front/images/1.png" class="img-fluid" width="100%" /></div>
                                            <div class="col-md-10 col-10">
                                                <p><a href="#">Release of Offer Letter for CHO January 2020 Session (April 20-Sep20)</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="box">
                                        <div class="row">
                                            <div class="col-md-2 col-2"><img src="assets/front/images/1.png" width="100%" /></div>
                                            <div class="col-md-10 col-10">
                                                <p><a href="#">Release of Offer Letter for CHO January 2020 Session (April 20-Sep20)</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="box">
                                        <div class="row">
                                            <div class="col-md-2 col-2"><img src="assets/front/images/1.png" width="100%" /></div>
                                            <div class="col-md-10 col-10">
                                                <p><a href="#">Release of Offer Letter for CHO January 2020 Session (April 20-Sep20)</a></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="item carousel-item">
                                    <div class="box">
                                        <div class="row">
                                            <div class="col-md-2 col-2"><img src="assets/front/images/1.png" width="100%" /></div>
                                            <div class="col-md-10 col-10">
                                                <p><a href="#">Release of Offer Letter for CHO January 2020 Session (April 20-Sep20)</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="box">
                                        <div class="row">
                                            <div class="col-md-2 col-2"><img src="assets/front/images/1.png" width="100%" /></div>
                                            <div class="col-md-10 col-10">
                                                <p><a href="#">Release of Offer Letter for CHO January 2020 Session (April 20-Sep20)</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="box">
                                        <div class="row">
                                            <div class="col-md-2 col-2"><img src="assets/front/images/1.png" width="100%" /></div>
                                            <div class="col-md-10 col-10">
                                                <p><a href="#">Release of Offer Letter for CHO January 2020 Session (April 20-Sep20)</a></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="item carousel-item">
                                    <div class="box">
                                        <div class="row">
                                            <div class="col-md-2 col-2"><img src="assets/front/images/1.png" width="100%" /></div>
                                            <div class="col-md-10 col-10">
                                                <p><a href="#">Release of Offer Letter for CHO January 2020 Session (April 20-Sep20)</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="box">
                                        <div class="row">
                                            <div class="col-md-2 col-2"><img src="assets/front/images/1.png" width="100%" /></div>
                                            <div class="col-md-10 col-10">
                                                <p><a href="#">Release of Offer Letter for CHO January 2020 Session (April 20-Sep20)</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="box">
                                        <div class="row">
                                            <div class="col-md-2 col-2"><img src="assets/front/images/1.png" width="100%" /></div>
                                            <div class="col-md-10 col-10">
                                                <p><a href="#">Release of Offer Letter for CHO January 2020 Session (April 20-Sep20)</a></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <!-- Carousel controls -->
                            <a class="carousel-control left carousel-control-prev" href="#myCarousel2" data-slide="prev">
                                <i class="fa fa-angle-left"></i>
                            </a>
                            <a class="carousel-control right carousel-control-next" href="#myCarousel2" data-slide="next">
                                <i class="fa fa-angle-right"></i>
                            </a>
                        </div>
                    </div>
                </div>

               <div class="col-md-6">
                    <div class="event_container">
                        <h2><i class="fa fa-angle-right ic" aria-hidden="true"></i> Latest Meeting<br /></h2>
                        <div id="myCarousel3" class="carousel slide" data-ride="carousel">
                            <div class="carousel-inner">
                                <div class="item carousel-item active">
                                    <div class="box">
                                        <div class="row">
                                            <div class="col-md-2 col-2"><img src="assets/front/images/1.png" class="img-fluid" width="100%" /></div>
                                            <div class="col-md-10 col-10">
                                                <p><a href="#">Release of Offer Letter for CHO January 2020 Session (April 20-Sep20)</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="box">
                                        <div class="row">
                                            <div class="col-md-2 col-2"><img src="assets/front/images/1.png" width="100%" /></div>
                                            <div class="col-md-10 col-10">
                                                <p><a href="#">Release of Offer Letter for CHO January 2020 Session (April 20-Sep20)</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="box">
                                        <div class="row">
                                            <div class="col-md-2 col-2"><img src="assets/front/images/1.png" width="100%" /></div>
                                            <div class="col-md-10 col-10">
                                                <p><a href="#">Release of Offer Letter for CHO January 2020 Session (April 20-Sep20)</a></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="item carousel-item">
                                    <div class="box">
                                        <div class="row">
                                            <div class="col-md-2 col-2"><img src="assets/front/images/1.png" width="100%" /></div>
                                            <div class="col-md-10 col-10">
                                                <p><a href="#">Release of Offer Letter for CHO January 2020 Session (April 20-Sep20)</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="box">
                                        <div class="row">
                                            <div class="col-md-2 col-2"><img src="assets/front/images/1.png" width="100%" /></div>
                                            <div class="col-md-10 col-10">
                                                <p><a href="#">Release of Offer Letter for CHO January 2020 Session (April 20-Sep20)</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="box">
                                        <div class="row">
                                            <div class="col-md-2 col-2"><img src="assets/front/images/1.png" width="100%" /></div>
                                            <div class="col-md-10 col-10">
                                                <p><a href="#">Release of Offer Letter for CHO January 2020 Session (April 20-Sep20)</a></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="item carousel-item">
                                    <div class="box">
                                        <div class="row">
                                            <div class="col-md-2 col-2"><img src="assets/front/images/1.png" width="100%" /></div>
                                            <div class="col-md-10 col-10">
                                                <p><a href="#">Release of Offer Letter for CHO January 2020 Session (April 20-Sep20)</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="box">
                                        <div class="row">
                                            <div class="col-md-2 col-2"><img src="assets/front/images/1.png" width="100%" /></div>
                                            <div class="col-md-10 col-10">
                                                <p><a href="#">Release of Offer Letter for CHO January 2020 Session (April 20-Sep20)</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="box">
                                        <div class="row">
                                            <div class="col-md-2 col-2"><img src="assets/front/images/1.png" width="100%" /></div>
                                            <div class="col-md-10 col-10">
                                                <p><a href="#">Release of Offer Letter for CHO January 2020 Session (April 20-Sep20)</a></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <!-- Carousel controls -->
                            <a class="carousel-control left carousel-control-prev" href="#myCarousel3" data-slide="prev">
                                <i class="fa fa-angle-left"></i>
                            </a>
                            <a class="carousel-control right carousel-control-next" href="#myCarousel3" data-slide="next">
                                <i class="fa fa-angle-right"></i>
                            </a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>



    <!--About us-->

    <div class="about_section">
        <div class="layer">
            <div class="container">
                <div class="row">
                    <div class="col-md-9 col-12">
                        <h5>Let's Know</h5>
                        <h3>About Us</h3>
                        <p>The National Health Mission (NHM) was designed with the aim of providing accessible, affordable, effective and reliable healthcare facilities in the rural and urban areas of the country, especially to the poor and vulnerable sections
                            of the population.<br /><br /> In the State of Uttar Pradesh, National Health Mission has made special efforts for reaching out to the community at grassroots level. NHM focuses on affordable, accessible, accountable, effective
                            and quality services to the masses specially to the vulnerable groups of the community.</p>
                    </div>

                    <div class="col-md-3 col-3 ab_right"><img src="assets/front/images/about.jpg" width="100%" /></div>
                </div>
            </div>
        </div>
    </div>


    <!--Other Links-->

    <div class="other_links mt-40 mb-5">
        <div class="container">
            <div class="row">

                <div class="col-md-7">
                    <h5>Some Other</h5>
                    <h3>Navigation</h3>

                    <ul id="accordion" class="accordion">
                        <li>
                            <div class="link">About Us<i class="fa fa-angle-down"></i></div>
                            <ul class="submenu">
                                <li><a href="#">Organochart</a></li>
                                <li><a href="#" target="_blank">Mission Document</a></li>
                            </ul>
                        </li>

                        <li>
                            <div class="link">NHM Initiatives<i class="fa fa-angle-down"></i></div>
                            <ul class="submenu">
                                <li><a href="#">ASHA</a></li>
                            </ul>
                        </li>

                        <li>
                            <a href="#">
                                <div class="link"> Achievements</div>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <div class="link"> ASHA Database</div>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <div class="link"> Contractual Staff</div>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <div class="link"> Days to Remember</div>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <div class="link"> Dist. Action Plan</div>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <div class="link">EMTS Cell & Service</div>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <div class="link">Government Orders</div>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <div class="link">Health Forum</div>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <div class="link">Health Statistics</div>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <div class="link"> MIS</div>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <div class="link">PIPs</div>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <div class="link"> Quality Assurance</div>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <div class="link"> Reports</div>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <div class="link"> Resource Material</div>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <div class="link"> RSBY</div>
                            </a>
                        </li>
                        <li>
                            <a href="#" target="_blank">
                                <div class="link"> SPMU Staff</div>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <div class="link">Trainings Update</div>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <div class="link">Useful Links</div>
                            </a>
                        </li>
                    </ul>

                </div>

                <div class="col-md-5">
                    <h5>Our</h5>
                    <h3>Success Stories</h3>

                    <div id="demo" class="carousel slide" data-ride="carousel">


                        <!-- Wrapper for carousel items -->
                        <div class="carousel-inner">
                            <div class="item carousel-item active">
                                <div class="img-box"><img src="assets/front/images/ASHAUnderCCSP.png" alt=""></div>
                                <p class="testimonial">उत्तर प्रदेश में बाल स्वास्थ्य एवं पोषण की जो स्थिति है उसे सुधारने के लिये यह जरूरी है कि सम्बन्धित सेवाओं में जन समुदाय की भागीदारी बढ़ायी जाये और विभिन्न विभागों जैसे स्वास्थ्य विभाग, आई.सी.डी.एस., पंचायतीराज संस्थाओं
                                    और ग्राम्य विकास विभाग के प्रयासों को एकीकृत कर साझा प्रयास किया जाये। यह इस कारण भी एक चुनौती है क्योंकि बाल अधिकारों की पूर्ति हमारा दायित्व है। अच्छा स्वास्थ्य और पोषण राज्य में जन्मे हर बच्चे का अधिकार है।</p>
                                <p class="overview">>> JOB AIDS Tools For ASHA Under CCSP
                                    <<</p>
                            </div>

                            <div class="item carousel-item">
                                <div class="img-box"><img src="assets/front/images/asha2009.png" alt=""></div>
                                <p class="testimonial"> राष्ट्रीय ग्रामीण स्वास्थ्य मिशन के अन्तर्गत, प्रदेश में 23 अगस्त 2005 को आशा योजना का शुभारम्भ किया गया था। राष्ट्रीय ग्रामीण स्वास्थ्य मिशन में स्वास्थ्य कार्यक्रमों के सामुदायकीकरण के लिये आशा की महत्वपूर्ण भूमिका है।
                                    प्रदेश में आशा योजना लागू किये जाने के उपलक्ष्य में प्रत्येक वर्ष 23 अगस्त को आशा दिवस के रूप में मनाया जाता है। आशा दिवस/सम्मेलन का आयोजन के उद्देश्य ग्रामीण स्वास्थ्य मिशन का आधार कही जाने वाली आशाओं को उनके द्वारा
                                    समुदाय में किये गये सराहयनीय प्रयासों के लिये उत्सिहत करना, मनोबल बढ़ाना, एवं सम्मानित करना।</p>
                                <p class="overview">>> आशा सम्मेलन 2009-2010
                                    <<</p>
                            </div>

                            <div class="item carousel-item">
                                <div class="img-box"><img src="assets/front/images/sasbahu.png" alt=""></div>
                                <p class="testimonial">राष्ट्रीय ग्रामीण स्वास्थ्य मिशन के अन्तर्गत, प्रदेश में 23 अगस्त 2005 को आशा योजना का शुभारम्भ किया गया था। राष्ट्रीय ग्रामीण स्वास्थ्य मिशन में स्वास्थ्य कार्यक्रमों के सामुदायकीकरण के लिये आशा की महत्वपूर्ण भूमिका है।
                                    प्रदेश में आशा योजना लागू किये जाने के उपलक्ष्य में प्रत्येक वर्ष 23 अगस्त को आशा दिवस के रूप में मनाया जाता है। आशा दिवस/सम्मेलन का आयोजन के उद्देश्य ग्रामीण स्वास्थ्य मिशन का आधार कही जाने वाली आशाओं को उनके द्वारा
                                    समुदाय में किये गये सराहयनीय प्रयासों के लिये उत्सिहत करना, मनोबल बढ़ाना, एवं सम्मानित करना।</p>
                                <p class="overview">>> आशा सम्मेलन 2009-2010
                                    <<</p>
                            </div>

                        </div>
                        <!-- Carousel controls -->
                        <a class="carousel-control left carousel-control-prev" href="#demo" data-slide="prev">
                            <i class="fa fa-angle-left"></i>
                        </a>
                        <a class="carousel-control right carousel-control-next" href="#demo" data-slide="next">
                            <i class="fa fa-angle-right"></i>
                        </a>
                    </div>




                </div>

            </div>
        </div>
    </div>




