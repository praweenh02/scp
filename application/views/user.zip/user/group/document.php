<div class="page-heading">
    <div class="row">
        <div class="col-md-8">
            <h3>
            SDO  - <span><?=$group_data->category_name;?></span>
            &nbsp;&nbsp;
            Working Group - <span><?=$group_data->group_title;?></span>
            </h3>
        </div>
    </div>
</div>
<div class="wrapper">
    <div class="row">
        <div class="col-sm-12">
            <section class="panel">
                <header class="panel-heading">
                    SDO  Bulletin
                    <!--<span class="tools pull-right">
                        <a href="javascript:;" class="fa fa-chevron-down"></a>
                        <a href="javascript:;" class="fa fa-times"></a>
                    </span>-->
                </header>
                <div class="panel-body">
                    <section id="unseen">
                        <table class="table table-bordered table-striped table-condensed">
                            <thead>
                                <tr>
                                    <th class="numeric">Sr.No</th>
                                    <th>Title</th>
                                    <th>SDO/Group</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $i=1;
                                foreach($sdo_list as $sdo_result){
                                ?>
                                <tr>
                                    <td class="numeric"><?=$i;?></td>
                                    <td>
                                        <?php
                                        echo $sdo_result->bulletin_title;
                                        ?>
                                    </td>
                                    <td>
                                        <a target="_blank" href="home/groups/<?=$sdo_result->sdo_id;?>?groupId=<?=base64_encode($sdo_result->group_id);?>">
                                            <?=$sdo_result->category_name;?>/<?=$sdo_result->group_title;?>
                                        </a>
                                    </td>
                                    <td>
                                        <?php
                                        echo date('d-m-Y', strtotime($sdo_result->created_at));
                                        ?>
                                    </td>
                                </tr>
                                <?php $i++; }?>
                            </tbody>
                        </table>
                    </section>
                    <hr>
                </div>
            </section>
            <section class="panel">
                <header class="panel-heading">
                    Member Upoloaded Contribution
                </header>
                <table class="table table-bordered table-striped table-condensed">
                    <thead>
                        <tr>
                            <th class="numeric">Sr.No</th>
                            <th class="numeric">Unique No.</th>
                            <th class="numeric">Meeting Name</th>
                            <th>Title</th>
                            <th>Source</th>
                            <th>AI/Question</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i=1;
                        foreach ($doc_reg_list as $docreg_data){
                        ?>
                        <tr>
                            <td><?=$i;?></td>
                            <td>
                                <?php
                                if($docreg_data->file)
                                {?>
                                <a target="_blank" href="<?=base_url();?>uploads/files/<?=$docreg_data->file;?>" ><?=$docreg_data->unique_no;?> </a>
                                <?php }else{?>
                                    <?=$docreg_data->unique_no;?>

                                <?php }
                                ?>
                            </td>
                            <td><?=$docreg_data->meeting_title;?></td>
                            <td><?=$docreg_data->title;?>
                                <br>
                                <?php
                                if($docreg_data->group_manager_status=='accept')
                                {?>
                                <span style="font-size:10px; color: red;">To be verified by GM  </span>
                                <?php }else if($docreg_data->group_manager_status=='reject'){ ?>
                                <span style="font-size:10px; color: red;">To be rejected by GM  </span>
                                <?php }?>
                            </td>
                            <td><?=$docreg_data->name;?> <?=$docreg_data->surname;?></td>
                            <td>
                                <?=$docreg_data->question_no;?>/<?=$docreg_data->question_name;?>
                            </td>
                            <td>
                                <?php
                                echo date('d-m-Y', strtotime($docreg_data->file_uploaded_date));
                                ?>
                            </td>
                        </tr>
                        <?php $i++; }?>
                    </tbody>
                </table>
            </section>
            <section class="panel">
                <header class="panel-heading">
                   Minutes of Meetings
                </header>
                <table class="table table-hover table-bordered table-striped table-condensed">
                    <thead>
                        <tr>
                            <th class="numeric">Sr.No</th>
                            <th class="numeric">Title</th>
                            <th class="numeric">Meeting Date</th>
                            <th class="numeric">Group</th>
                            <th class="numeric">Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i=1;
                        foreach ($meeting_list as $meeting_result){
                        ?>
                        <tr>
                            <td><?=$i;?></td>
                            <td>
                                <?php
                                if($meeting_result->meeting_file)
                                {?>
                                <a target="_blank" href="<?=base_url();?>uploads/outcome-documents/<?=$meeting_result->meeting_file;?>" ><?=$meeting_result->meeting_title;?> </a>
                                <?php }else{ ?>
                                    <?=$meeting_result->meeting_title;?> 

                                <?php }
                                ?>
                            </td>
                            <td>
                               <?=date('d-m-Y', strtotime($meeting_result->meeting_date));?>
                            </td>
                            <td>
                              <?=$meeting_result->group_title;?>  
                            </td>

                            <td>
                                <?php
                                echo date('d-m-Y', strtotime($meeting_result->created_at));
                                ?>
                            </td>
                        </tr>
                        <?php $i++; }?>
                    </tbody>
                </table>
            </section>
            <section class="panel">
                <header class="panel-heading">
                    Outcome Document
                </header>
                <table class="table table-hover table-bordered table-striped table-condensed">
                    <thead>
                        <tr>
                            <th class="numeric">Sr.No</th>
                            <th class="numeric">Title</th>
                            <th class="numeric">Group/Meeting Details</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i=1;
                        foreach ($outcome_list as $outcome_result){
                        ?>
                        <tr>
                            <td><?=$i;?></td>
                            <td>
                                <?php
                                if($outcome_result->outcome_file)
                                {?>
                                <a target="_blank" href="<?=base_url();?>uploads/outcome-documents/<?=$outcome_result->outcome_file;?>" ><?=$outcome_result->outcome_document_title;?> </a>
                                <?php }else{ ?>
                                       <?=$outcome_result->outcome_document_title;?>
                                <?php }
                                ?>
                            </td>
                            <td>
                                <?=$outcome_result->group_title;?> / <?=$outcome_result->meeting_title;?> - <?=date('d-m-Y', strtotime($outcome_result->meeting_date));?>
                            </td>

                            <td>
                                <?php
                                echo date('d-m-Y', strtotime($outcome_result->created_at));
                                ?>
                            </td>
                        </tr>
                        <?php $i++; }?>
                    </tbody>
                </table>
            </section>
             <section class="panel">
                <header class="panel-heading">
                    Document from ITU site
                </header>
                <table class="table table-hover table-bordered table-striped table-condensed">
                    <thead>
                        <tr>
                            <th class="numeric">Sr.No</th>
                            <th class="numeric">Title</th>
                            <th class="numeric">Group/Meeting Details</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i=1;
                        foreach ($documentfromitu_list as $itu_result){
                        ?>
                        <tr>
                            <td><?=$i;?></td>
                            <td>
                                <?php
                                if($outcome_result->outcome_file)
                                {?>
                                <a target="_blank" href="<?=base_url();?>uploads/outcome-documents/<?=$outcome_result->outcome_file;?>" ><?=$outcome_result->outcome_document_title;?> </a>
                                <?php }else{ ?>
                                       <?=$outcome_result->outcome_document_title;?>
                                <?php }
                                ?>
                            </td>
                            <td>
                                <?=$outcome_result->group_title;?> / <?=$outcome_result->meeting_title;?> - <?=date('d-m-Y', strtotime($outcome_result->meeting_date));?>
                            </td>

                            <td>
                                <?php
                                echo date('d-m-Y', strtotime($outcome_result->created_at));
                                ?>
                            </td>
                        </tr>
                        <?php $i++; }?>
                    </tbody>
                </table>
            </section>
        </div>
    </div>
</div>
