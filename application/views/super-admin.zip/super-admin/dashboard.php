 <!-- page heading start-->
        <div class="page-heading">
            <h3>
                Dashboard
            </h3>
          <hr>
           
        </div>
        <!-- page heading end-->

     
   <!--body wrapper start-->
        <div class="wrapper">
            <div class="row">
                <div class="col-md-12">
                    <!--statistics start-->
                    <div class="row state-overview">
                         <div class="col-md-3 col-xs-12 col-sm-6">
                            <div class="panel red">
                                <div class="symbol">
                                    <i class="fa fa-user"></i>
                                </div>
                                <div class="state-value">
                                    <div class="value"><?=$total_new_member_request;?></div>
                                    <div class="title"> New Member Request</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-xs-12 col-sm-6">
                            <div class="panel purple">
                                <div class="symbol">
                                    <i class="fa fa-eye"></i>
                                </div>
                                <div class="state-value">
                                    <div class="value"><?=$total_group;?></div>
                                    <div class="title">Total Groups </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-xs-12 col-sm-6">
                            <div class="panel green">
                                <div class="symbol">
                                    <i class="fa fa-users"></i>
                                </div>
                                <div class="state-value">
                                    <div class="value"><?=$taotal_users;?></div>
                                    <div class="title">Total Member</div>
                                </div>
                            </div>
                        </div>
                         <div class="col-md-3 col-xs-12 col-sm-6">
                            <div class="panel blue">
                                <div class="symbol">
                                    <i class="fa fa-users"></i>
                                </div>
                                <div class="state-value">
                                    <div class="value"><?=$taotal_gmanager;?></div>
                                    <div class="title"> Total Group Managers</div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                    <div class="row state-overview">
                      
                        <div class="col-md-3 col-xs-12 col-sm-6">
                            <div class="panel green">
                                <div class="symbol">
                                    <i class="fa fa-file-text"></i>
                                </div>
                                <div class="state-value">
                                    <div class="value">0</div>
                                    <div class="title">Total Files</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--statistics end-->
                </div>
                
            </div>
           </div>

        </div>